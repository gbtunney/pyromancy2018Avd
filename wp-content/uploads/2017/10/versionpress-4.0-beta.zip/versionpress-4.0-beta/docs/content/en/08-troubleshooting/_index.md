# Troubleshooting

We collect solutions to various common issues here. Generally, if you want to report an issue, please file a new ticket in [this GitHub repo](https://github.com/versionpress/support).
